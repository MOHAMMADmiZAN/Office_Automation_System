### Getting Started

- clone the project `https://github.com/MOHAMMADmiZAN/Office_Automation_System` then go to `cd client` and `npm i` 
- First, run the development server: `npm run dev`



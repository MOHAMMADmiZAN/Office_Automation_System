const customTabsStyle = {
    '& .MuiTabs-indicator': {

    },
    '& .MuiTabs-flexContainer': {
        justifyContent: 'space-between',

    }
}

export default customTabsStyle
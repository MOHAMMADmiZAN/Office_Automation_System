const loginStyle = {}

export default loginStyle
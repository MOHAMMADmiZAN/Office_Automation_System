const indexPageStyle = {


}
export default indexPageStyle;